export type Question = {
  prompt: string
  answers: string[]
  correct: number
}

export type Category = {
  id: string
  title: string
  emoji: string
  // tailwind-ish solid color hex used for accents
  color: string
  questions: Question[]
}

export const categories: Category[] = [
  {
    id: "capitales",
    title: "Capitales",
    emoji: "🌍",
    color: "#22c55e", // green
    questions: [
      { prompt: "Quelle est la capitale du Japon ?", answers: ["Tokyo", "Pékin", "Séoul", "Bangkok"], correct: 0 },
      { prompt: "Quelle est la capitale de l'Australie ?", answers: ["Sydney", "Melbourne", "Canberra", "Perth"], correct: 2 },
      { prompt: "Quelle est la capitale du Canada ?", answers: ["Toronto", "Ottawa", "Montréal", "Vancouver"], correct: 1 },
      { prompt: "Quelle est la capitale du Brésil ?", answers: ["Rio de Janeiro", "São Paulo", "Brasília", "Salvador"], correct: 2 },
      { prompt: "Quelle est la capitale de l'Égypte ?", answers: ["Le Caire", "Alexandrie", "Gizeh", "Louxor"], correct: 0 },
    ],
  },
  {
    id: "drapeaux",
    title: "Drapeaux",
    emoji: "🚩",
    color: "#3b82f6", // blue
    questions: [
      { prompt: "Quel pays a un drapeau rouge avec une feuille d'érable ?", answers: ["États-Unis", "Canada", "Suisse", "Danemark"], correct: 1 },
      { prompt: "Quel pays a un drapeau avec un soleil rouge sur fond blanc ?", answers: ["Chine", "Corée du Sud", "Japon", "Vietnam"], correct: 2 },
      { prompt: "Quel pays a un drapeau vert, blanc et rouge avec un aigle ?", answers: ["Italie", "Mexique", "Hongrie", "Iran"], correct: 1 },
      { prompt: "Quel pays a un drapeau bleu, blanc et rouge vertical ?", answers: ["France", "Pays-Bas", "Russie", "Luxembourg"], correct: 0 },
      { prompt: "Quel pays a un drapeau avec une croix jaune sur fond bleu ?", answers: ["Finlande", "Norvège", "Suède", "Islande"], correct: 2 },
    ],
  },
  {
    id: "monuments",
    title: "Monuments",
    emoji: "🏛️",
    color: "#f97316", // orange
    questions: [
      { prompt: "Où se trouve le Colisée ?", answers: ["Athènes", "Rome", "Naples", "Istanbul"], correct: 1 },
      { prompt: "Dans quel pays se trouve le Taj Mahal ?", answers: ["Pakistan", "Népal", "Inde", "Bangladesh"], correct: 2 },
      { prompt: "Où se trouve la Sagrada Família ?", answers: ["Madrid", "Barcelone", "Valence", "Séville"], correct: 1 },
      { prompt: "Dans quelle ville est la statue de la Liberté ?", answers: ["Boston", "Washington", "New York", "Chicago"], correct: 2 },
      { prompt: "Où se trouve le Machu Picchu ?", answers: ["Pérou", "Bolivie", "Équateur", "Chili"], correct: 0 },
    ],
  },
  {
    id: "monnaies",
    title: "Monnaies",
    emoji: "💰",
    color: "#a855f7", // violet
    questions: [
      { prompt: "Quelle est la monnaie du Japon ?", answers: ["Won", "Yuan", "Yen", "Baht"], correct: 2 },
      { prompt: "Quelle est la monnaie du Royaume-Uni ?", answers: ["Euro", "Livre sterling", "Dollar", "Franc"], correct: 1 },
      { prompt: "Quelle est la monnaie de l'Inde ?", answers: ["Roupie", "Taka", "Rial", "Dinar"], correct: 0 },
      { prompt: "Quelle est la monnaie de la Suisse ?", answers: ["Euro", "Couronne", "Franc suisse", "Mark"], correct: 2 },
      { prompt: "Quelle est la monnaie du Mexique ?", answers: ["Real", "Peso", "Sol", "Quetzal"], correct: 1 },
    ],
  },
  {
    id: "culture",
    title: "Culture",
    emoji: "🧠",
    color: "#ef4444", // red
    questions: [
      { prompt: "Quel est le plus long fleuve du monde ?", answers: ["Amazone", "Nil", "Yangtsé", "Mississippi"], correct: 1 },
      { prompt: "Combien de continents y a-t-il ?", answers: ["5", "6", "7", "8"], correct: 2 },
      { prompt: "Quel est le pays le plus peuplé du monde ?", answers: ["Chine", "Inde", "États-Unis", "Indonésie"], correct: 1 },
      { prompt: "Quel océan est le plus grand ?", answers: ["Atlantique", "Indien", "Arctique", "Pacifique"], correct: 3 },
      { prompt: "Quelle langue est la plus parlée au monde ?", answers: ["Anglais", "Mandarin", "Espagnol", "Hindi"], correct: 1 },
    ],
  },
  {
    id: "defis",
    title: "Défis",
    emoji: "⚡",
    color: "#06b6d4", // cyan
    questions: [
      { prompt: "Quel pays a le plus de fuseaux horaires ?", answers: ["Russie", "États-Unis", "France", "Chine"], correct: 2 },
      { prompt: "Quel est le plus petit pays du monde ?", answers: ["Monaco", "Vatican", "Nauru", "Saint-Marin"], correct: 1 },
      { prompt: "Quel désert est le plus grand du monde ?", answers: ["Sahara", "Gobi", "Antarctique", "Arabique"], correct: 2 },
      { prompt: "Quelle est la plus haute montagne du monde ?", answers: ["K2", "Everest", "Kilimandjaro", "Mont Blanc"], correct: 1 },
      { prompt: "Quel pays compte le plus d'îles ?", answers: ["Indonésie", "Philippines", "Suède", "Japon"], correct: 2 },
    ],
  },
]
