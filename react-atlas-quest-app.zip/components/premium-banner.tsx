type PremiumBannerProps = {
  onClick?: () => void
}

export function PremiumBanner({ onClick }: PremiumBannerProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex w-full items-center justify-between gap-3 rounded-2xl bg-gradient-to-r from-amber-400 to-yellow-500 px-5 py-4 text-left shadow-lg transition-transform active:scale-[0.98]"
    >
      <div>
        <p className="flex items-center gap-2 text-base font-bold text-amber-950">
          <span aria-hidden="true">👑</span> Passer à Premium
        </p>
        <p className="text-sm text-amber-900/80">Débloque tous les défis et le mode hors-ligne</p>
      </div>
      <span className="shrink-0 rounded-full bg-amber-950 px-3 py-1.5 text-sm font-bold text-amber-300">
        10€/mois
      </span>
    </button>
  )
}
