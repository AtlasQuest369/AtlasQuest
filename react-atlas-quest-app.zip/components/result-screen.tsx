import type { Category } from "@/lib/quiz-data"

type ResultScreenProps = {
  category: Category
  score: number
  total: number
  xpEarned: number
  onReplay: () => void
  onHome: () => void
}

export function ResultScreen({
  category,
  score,
  total,
  xpEarned,
  onReplay,
  onHome,
}: ResultScreenProps) {
  const percent = Math.round((score / total) * 100)
  const message =
    percent === 100
      ? "Parfait ! 🏆"
      : percent >= 60
        ? "Bien joué ! 🎉"
        : "Continue à explorer ! 🧭"

  return (
    <div className="flex w-full max-w-md flex-col items-center gap-6 text-center">
      <span className="text-6xl" aria-hidden="true">
        {category.emoji}
      </span>
      <h2 className="text-2xl font-extrabold text-slate-50">{message}</h2>

      <div
        className="flex h-40 w-40 flex-col items-center justify-center rounded-full border-8"
        style={{ borderColor: category.color }}
      >
        <span className="text-4xl font-black text-slate-50">
          {score}/{total}
        </span>
        <span className="text-sm font-semibold text-slate-400">{percent}%</span>
      </div>

      <div className="flex items-center gap-2 rounded-full bg-green-500/15 px-5 py-2.5 text-green-400">
        <span className="text-lg font-bold">+{xpEarned} XP</span>
        <span aria-hidden="true">⚡</span>
      </div>

      <div className="flex w-full flex-col gap-3">
        <button
          type="button"
          onClick={onReplay}
          className="w-full rounded-xl bg-slate-50 px-4 py-4 text-base font-bold text-slate-950 transition-transform active:scale-95"
        >
          Rejouer
        </button>
        <button
          type="button"
          onClick={onHome}
          className="w-full rounded-xl bg-slate-800 px-4 py-4 text-base font-bold text-slate-100 transition-transform active:scale-95"
        >
          Accueil
        </button>
      </div>
    </div>
  )
}
