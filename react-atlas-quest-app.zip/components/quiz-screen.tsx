"use client"

import { useState } from "react"
import type { Category } from "@/lib/quiz-data"

type QuizScreenProps = {
  category: Category
  onFinish: (score: number, total: number) => void
  onQuit: () => void
}

export function QuizScreen({ category, onFinish, onQuit }: QuizScreenProps) {
  const [index, setIndex] = useState(0)
  const [selected, setSelected] = useState<number | null>(null)
  const [score, setScore] = useState(0)

  const question = category.questions[index]
  const isLast = index === category.questions.length - 1

  function handleSelect(i: number) {
    if (selected !== null) return
    setSelected(i)
    if (i === question.correct) setScore((s) => s + 1)
  }

  function handleNext() {
    if (isLast) {
      onFinish(score, category.questions.length)
    } else {
      setIndex((n) => n + 1)
      setSelected(null)
    }
  }

  function answerClasses(i: number) {
    const base =
      "w-full rounded-xl px-4 py-4 text-left text-base font-semibold transition-colors"
    if (selected === null) {
      return `${base} bg-slate-800 text-slate-100 hover:bg-slate-700`
    }
    if (i === question.correct) {
      return `${base} bg-green-500 text-slate-950`
    }
    if (i === selected) {
      return `${base} bg-red-500 text-slate-50`
    }
    return `${base} bg-slate-800 text-slate-500`
  }

  return (
    <div className="flex w-full max-w-md flex-col gap-6">
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={onQuit}
          className="text-sm font-semibold text-slate-400 hover:text-slate-200"
        >
          ← Quitter
        </button>
        <span className="font-mono text-sm text-slate-400">
          {index + 1} / {category.questions.length}
        </span>
      </div>

      <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
        <div
          className="h-full rounded-full transition-all duration-300"
          style={{
            width: `${((index + 1) / category.questions.length) * 100}%`,
            backgroundColor: category.color,
          }}
        />
      </div>

      <div className="flex items-center gap-3">
        <span className="text-3xl" aria-hidden="true">
          {category.emoji}
        </span>
        <h2 className="text-balance text-xl font-bold text-slate-50">
          {question.prompt}
        </h2>
      </div>

      <div className="flex flex-col gap-3">
        {question.answers.map((answer, i) => (
          <button
            key={i}
            type="button"
            onClick={() => handleSelect(i)}
            className={answerClasses(i)}
            disabled={selected !== null}
          >
            {answer}
          </button>
        ))}
      </div>

      {selected !== null && (
        <button
          type="button"
          onClick={handleNext}
          className="w-full rounded-xl bg-slate-50 px-4 py-4 text-base font-bold text-slate-950 transition-transform active:scale-95"
        >
          {isLast ? "Voir le résultat" : "Question suivante"}
        </button>
      )}
    </div>
  )
}
