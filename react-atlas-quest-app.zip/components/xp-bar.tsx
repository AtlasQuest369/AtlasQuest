type XpBarProps = {
  level: number
  progress: number // 0-100
}

export function XpBar({ level, progress }: XpBarProps) {
  return (
    <div className="w-full">
      <div className="mb-2 flex items-center justify-between text-sm">
        <span className="flex items-center gap-2 font-semibold text-slate-200">
          <span className="flex h-7 w-7 items-center justify-center rounded-full bg-green-500 text-xs font-bold text-slate-950">
            {level}
          </span>
          Niveau {level}
        </span>
        <span className="font-mono text-xs text-slate-400">{progress}%</span>
      </div>
      <div className="h-3 w-full overflow-hidden rounded-full bg-slate-800">
        <div
          className="h-full rounded-full bg-green-500 transition-all duration-500"
          style={{ width: `${progress}%` }}
          role="progressbar"
          aria-valuenow={progress}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label={`Progression du niveau ${level}`}
        />
      </div>
    </div>
  )
}
