import type { Category } from "@/lib/quiz-data"

type CategoryCardProps = {
  category: Category
  onClick: () => void
}

export function CategoryCard({ category, onClick }: CategoryCardProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="group flex aspect-square flex-col items-start justify-between rounded-2xl p-4 text-left shadow-lg transition-transform active:scale-95"
      style={{ backgroundColor: category.color }}
    >
      <span className="text-4xl" aria-hidden="true">
        {category.emoji}
      </span>
      <div className="text-slate-950">
        <p className="text-lg font-extrabold leading-tight">{category.title}</p>
        <p className="text-xs font-semibold text-slate-950/70">
          {category.questions.length} questions
        </p>
      </div>
    </button>
  )
}
