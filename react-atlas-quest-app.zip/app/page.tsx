"use client"

import { useState } from "react"
import { categories, type Category } from "@/lib/quiz-data"
import { XpBar } from "@/components/xp-bar"
import { CategoryCard } from "@/components/category-card"
import { QuizScreen } from "@/components/quiz-screen"
import { ResultScreen } from "@/components/result-screen"
import { PremiumBanner } from "@/components/premium-banner"

type Screen = "home" | "quiz" | "result"

export default function Page() {
  const [screen, setScreen] = useState<Screen>("home")
  const [active, setActive] = useState<Category | null>(null)
  const [result, setResult] = useState({ score: 0, total: 0, xp: 0 })
  const [level] = useState(3)
  const [progress, setProgress] = useState(45)

  function startQuiz(category: Category) {
    setActive(category)
    setScreen("quiz")
  }

  function finishQuiz(score: number, total: number) {
    const xp = score * 20
    setResult({ score, total, xp })
    setProgress((p) => Math.min(100, p + xp / 4))
    setScreen("result")
  }

  function goHome() {
    setScreen("home")
    setActive(null)
  }

  return (
    <main className="flex min-h-screen justify-center bg-slate-900 px-5 py-8">
      {screen === "home" && (
        <div className="flex w-full max-w-md flex-col gap-7">
          <header className="flex flex-col gap-1">
            <h1 className="text-3xl font-black tracking-tight text-slate-50">
              <span aria-hidden="true">🗺️</span> AtlasQuest
            </h1>
            <p className="text-base text-slate-400">Apprendre le monde en jouant</p>
          </header>

          <XpBar level={level} progress={Math.round(progress)} />

          <section aria-label="Catégories" className="grid grid-cols-2 gap-4">
            {categories.map((category) => (
              <CategoryCard
                key={category.id}
                category={category}
                onClick={() => startQuiz(category)}
              />
            ))}
          </section>

          <div className="mt-auto pt-2">
            <PremiumBanner />
          </div>
        </div>
      )}

      {screen === "quiz" && active && (
        <div className="flex w-full items-start justify-center pt-4">
          <QuizScreen category={active} onFinish={finishQuiz} onQuit={goHome} />
        </div>
      )}

      {screen === "result" && active && (
        <div className="flex w-full items-center justify-center">
          <ResultScreen
            category={active}
            score={result.score}
            total={result.total}
            xpEarned={result.xp}
            onReplay={() => startQuiz(active)}
            onHome={goHome}
          />
        </div>
      )}
    </main>
  )
}
